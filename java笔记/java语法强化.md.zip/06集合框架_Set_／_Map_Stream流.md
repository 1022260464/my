# 06集合框架|Set|／|Map|Stream流

- [ ] 敲一遍代码，熟悉集合框架，匿名内部类、Lambda、方法引用不是很熟

---

这部分知识点是集合进阶中的难点，特别是 `HashSet` 的去重原理，是面试中 100% 会被问到的问题。

为你整理了 **Set 集合全家桶** 的核心笔记，涵盖了底层原理和使用场景。

![image](assets/image-20260206221342-0ab1n4g.png)

---

### 📦 1. Set 集合的特点 (Overview)

​`Set`​ 接口继承自 `Collection`​，它的核心特点可以概括为  **“三无”** （针对最常用的 HashSet）：

1. **无序** (Unordered)：存取顺序不一致（你存 A, B, C，取出来可能是 C, A, B）。
2. **不重复** (Unique)：**这是 Set 最重要的特性**。如果插入重复元素，操作会被忽略（`add`​ 方法返回 `false`）。
3. **无索引** (No Index)：没有下标，不能通过 `get(i)` 来获取元素，只能通过迭代器或增强 for 循环遍历。

---

### 🗝️ 2. HashSet 集合的底层原理 (重点)

**一句话总结**：HashSet 的底层其实就是一个 **HashMap**。它把数据存储在 HashMap 的 **Key** 上，而 Value 只是一个占位的 Object 对象。

#### 核心结构：哈希表 (Hash Table)

在 JDK 8 以后，哈希表的结构是：**数组 + 链表 + 红黑树**。

#### 🚫 如何保证“不重复”？(去重机制)	

当你调用 `add(E e)` 时，HashSet 会执行以下步骤：

1. **算哈希**：调用元素对象的 `hashCode()` 方法，计算出哈希值。
2. **找位置**：根据哈希值，计算出该元素在底层数组中的位置（索引）。
3. **判断位置状态**：

- **情况 A：位置是空的** -> 直接存入。
- **情况 B：位置有数据** (哈希冲突) ->
- 先检查哈希值是否一样。
- 如果哈希值一样，再调用 `equals()` 方法比较内容。
- **如果 equals 返回 true**：认为是同一个元素，**舍弃**（不存）。
- **如果 equals 返回 false**：认为是不同元素，**挂在下面**（形成链表）。

>  **⚠️ 必须背下来的规则**：  
> 如果你把自定义对象（如 `Student`​）存入 HashSet，**必须同时重写** **​`hashCode()`​** ​ **和** **​`equals()`​** ​ **方法**，否则去重会失效！

#### 红黑树树化 (性能优化)

当链表长度超过 **8** 且数组长度 >= **64** 时，链表会自动转为**红黑树**，以提高查询效率。

---

### 底层原理(JDK 1.8加入红黑树优化)

#### 1. 核心参数准备 (初始化)

- ​**初始容量 (Capacity)** ​：`16`（默认）。

  - ​*注意*​：`new`​ 的时候不创建，**第一次** **​`put`​**​ **时**才懒加载创建。
- ​**加载因子 (Load Factor)** ​：`0.75`。

  - ​*含义*：数组填满 75% 就扩容。
  - ​*原理*​：这是**时间**与**空间**的折中。

    - 如果 \> 0.75（如 1.0）：空间省了，但哈希冲突增加，查询变慢。
    - 如果 \< 0.75（如 0.5）：冲突少了，查询快，但频繁扩容浪费空间。
- ​**扩容阈值 (Threshold)** ​：`16 * 0.75 = 12`。当元素个数超过 12 时触发。

---

#### 2. PUT 方法执行流程 (存数据)

**第一步：计算位置 (Hash & Index)**

1. ​**算 Hash**​：不仅仅是 `hashCode()`。

   - 公式：`(h = key.hashCode()) ^ (h >>> 16)`
   - ​*目的*：让高位也参与运算，打散哈希值，减少碰撞。
2. ​**算 Index**：不仅仅是取模。

   - 公式：`index = (n - 1) & hash`
   - ​*前提*​：数组长度 n 必须是 ​**2 的幂次方**。此时该位运算等价于取模，但效率极高。

**第二步：判断位置状态**

- **情况 A：位置是 null**

  - 直接创建 Node 存入。
- **情况 B：位置不是 null (发生哈希冲突)**

  1. ​**先比对首节点**​：比较 Hash 值和 key 的 `equals()`。

     - 如果相同 -\> **不存**
  2. ​**判断结构**​：检查当前节点是 `TreeNode`​ (红黑树) 还是 `Node` (链表)。

     - 如果是树 -\> 走**红黑树插入**逻辑。
     - 如果是链表 -\> 走**链表插入**逻辑。

**第三步：链表插入逻辑 (JDK 8 特性)** 	

1. **遍历链表**：采用**尾插法**（直接挂在最后面）。

   JDK 8之前，新元素存入数组，占老元素位置，老元素挂下面  
   **JDK 8开始之后，新元素直接挂在老元素下面**
2. ​**查重**：遍历过程中若发现 key 已存在，则覆盖。
3. ​**树化判断**：插入完成后，检查当前链表长度。

   - 如果长度 \> **8** 且 数组长度 \>\= ​**64**：
   - 👉 **链表转为红黑树** (O(n) -\> O(log n))。

---

#### 3. 扩容机制 (Resize) 

​**触发时机**​：`Size > Threshold (容量 * 0.75)`。

​**扩容动作**：

1. 创建新数组，长度是旧数组的 ​**2 倍**​（例如 16 -\> 32）。
2. ​**数据迁移 (Rehash 的优化)** ：

   - JDK 8 **不需要**像 JDK 7 那样重新计算每个元素的 Hash 值。
   - 它是通过观察\*\*Hash 值的二进制“高位”\*\*来决定的。

​**迁移规则 (高位判断)** ：

假设旧数组长度 16 (`10000`)，扩容到 32。

我们在计算下标时，只需要看 ​**hash 值倒数第 5 位**（也就是旧数组长度对应的那一位）是 0 还是 1：

- ​**如果是 0 (低位)** ：

  - 元素位置**不变** (仍在原索引)。
- ​**如果是 1 (高位)** ：

  - 元素位置 \= **原索引 + 旧数组长度** (原索引 + 16)。

> ​**总结效果**：
>
> 原本挤在同一个桶里的链表，扩容后会被**拆分**成两队。一队留在原地，一队搬到新家，从而瞬间缓解了拥堵。

---

这份总结涵盖了​**初始化、哈希计算、冲突处理、树化机制、扩容逻辑**​，特别是把 JDK 8 的**高位运算法则**讲清楚了。这样整理是否符合你的笔记标准？

---

### 🔗 3. LinkedHashSet 集合的底层原理

**特点**：**有序**、不重复、无索引。

> 这里的“有序”是指 **保证“怎么存就怎么取”**  (Insertion Order)。

**底层原理**：  
它是 HashSet 的子类。底层依然是哈希表，但它多做了一件事：**多维护了一个双向链表**。

- 每个节点不仅存数据，还记录了“上一个元素是谁”和“下一个元素是谁”。
- **作用**：在遍历时，不按照哈希表的随机顺序，而是按照双向链表的记录顺序来输出，从而实现了“有序”。

---

### 🌲 4. TreeSet 集合

**特点**：**可排序**、不重复、无索引。

> 这里的“可排序”是指 **按照数值大小或字典规则排序** (Sorted)，而不是插入顺序。

**底层原理**：  
基于 **红黑树 (Red-Black Tree)**  实现。红黑树是一种自平衡的二叉查找树，能保证数据自动排好序。

- 对于**数值类型**：Integer , Double，默认按照数值本身的大小进行升序排序。
- 对于**字符串类型**：默认按照首字符的编号升序排序。
- 对于**自定义类型如Student对象**，TreeSet默认是无法直接排序的。

#### 它的两种排序方式 (面试考点)

TreeSet 在添加元素时，会自动调用比较逻辑来确定节点位置。如果元素不知道怎么比较（比如两个 Student 对象），程序会报错。必须指定比较规则：

**两种方式中**，关于返回值的规则：  
如果认为第一个元素 >  第二个元素 返回正整数即可。**通常为1**  
如果认为第一个元素 < 第二个元素返回负整数即可。**通常为-1**  
如果认为第一个元素 = 第二个元素**返回0即可**，此时Treeset集合只会保留一个元素，认为两者重复。

**方式一：自然排序 (Comparable)**

- 让元素类（如 `Student`​）实现 `Comparable<Student>` 接口。
- 重写 `compareTo(Student o)`​ 方法，定义排序规则（如按年龄升序：`this.age - o.age`）。

**方式二：比较器排序 (Comparator)————较为推荐的写法**

- 在创建 TreeSet 集合时，直接在构造器中传一个 `Comparator` 对象（通常用 Lambda 表达式）。
- *场景：如果不方便修改* *​`Student`​*​ *类的源码，或者需要多种排序规则时使用。*

```java
// 示例：按照字符串长度排序，长度一样按字典序
TreeSet<String> ts = new TreeSet<>((s1, s2) -> {
    int lenDiff = s1.length() - s2.length();
    return lenDiff == 0 ? s1.compareTo(s2) : lenDiff;
});

```

---

## 总结:

#### 对比表:

|集合类型|**有序性**|**唯一性**|**底层结构**|**应用场景**|
| ----------| ------| ---------| -------------------| --------------------------------------|
|**HashSet**|无序|✅ 唯一|哈希表|**最常用**，仅仅为了去重，速度最快。|
|**LinkedHashSet**|**插入有序**|✅ 唯一|哈希表 + 双向链表|需要去重，且需要保留原本的输入顺序。|
|**TreeSet**|**数值排序**|✅ 唯一|红黑树|需要去重，且需要按照大小/规则排序。|

**复习建议**：  
重点把 **HashSet 的** **​`hashCode`​**​  **+**  **​`equals`​**​ **去重流程** 背下来，这是面试官最喜欢问的细节。

- ##### reeSet集合的特点是怎么样的？

  可排序、不重复、无索引  
  底层基于红黑树实现排序，增删改查性能较好
- ##### TreeSet集合对自定义类型的对象排序，有几种方式指定比较规则？

  2种。类实现Comparable接口，重写比较规则。集合自定义Comparator比较器对象，重写比较规则。

- #### 1、如果希望记住元素的添加顺序，需要存储重复的元素，又要频繁的根据索引查询数据？

  用ArrayList集合（有序、可重复、有索引），底层基于数组的。（常用）
- #### 2、如果希望记住元素的添加顺序，且增删首尾数据的情况较多？

  用LinkedList集合（有序、可重复、有索引），底层基于双链表实现的。
- #### 3.如果不在意元素顺序，也没有重复元素需要存储，只希望增删改查都快？

  用HashSet集合（无序，不重复，无索引），底层基于哈希表实现的。 （常用）

- #### 4.如果希望记住元素的添加顺序，也没有重复元素需要存储，且希望增删改查都快？

  用LinkedHashSet集合（有序，不重复，无索引）， 底层基于哈希表和双链表。

- #### 5.如果要对元素进行排序，也没有重复元素需要存储？且希望增删改查都快？

  用TreeSet集合，基于红黑树实现。

---

# MAP:

---

### 🗺️ 1. Map 集合概述 (Overview)

- ​**定义**​：`Map<K, V>`​ 是一个​**双列集合**​，存储的是 ​**键值对 (Key-Value Pair)** 。
- ​**核心特点**：

  1. ​**Key (键) 无序、不重复**：键是唯一的（像 Set）。
  2. ​**Value (值) 可重复**：值可以一样（像 List）。
  3. ​**一一对应**：一个键只能映射到一个值。
- ​**生活案例**：

  - 商品 ID (Key) -\> 商品信息 (Value)
  - 学号 (Key) -\> 学生姓名 (Value)
- **HashMap（由键决定特点）** : 无序、不重复、无索引；  （用的最多）  
  **LinkedHashMap （由键决定特点）** :由键决定的特点：有序、不重复、无索引。  
  **TreeMap （由键决定特点）** :按照大小默认升序排序、不重复、无索引。
- **注意：** Map系列集合的特点都是由键决定的，值只是一个附属品，**值是不做要求的**

---

### 🛠️ 2. Map 集合的常用方法 (API)

​`Map` 接口中的方法主要围绕“键值对”进行操作。

|**操作类型**|**方法名**|**说明**|**注意点 (坑)**|||||
| --| ------| ------------------| ---------------------------------------------| --| --| --| --|
|**增 / 改**|​`V put(K key, V value)`|添加/修改元素|1. 如果键不存在，存入并返回`null`。<br /><br />2.​**如果键已存在，覆盖旧值，并返回旧值**。|||||
|**删**|​`V remove(Object key)`|根据键删除|删除成功返回被删的值，否则返回`null`。|||||
||​`void clear()`|清空集合|-|||||
|**查**|​`V get(Object key)`|根据键获取值|键不存在返回`null`。|||||
||​`int size()`|获取键值对个数|-|||||
||​`boolean containsKey(Object key)`|判断是否包含某键|​**高频使用**，用来查重。|||||
||​`boolean containsValue(Object value)`|判断是否包含某值|-|||||
|**获取集合**|​`Set<K> keySet()`|**获取所有键**|返回一个 Set 集合。|||||
||​`Collection<V> values()`|获取所有值|返回一个 Collection 集合（因为值可重复）。|||||
||​`Set<Map.Entry<K,V>> entrySet()`|**获取所有键值对**|返回 Entry 对象的 Set 集合。|||||

---

### 🔄 3. Map 集合的遍历方式 (重点)

Map 没有迭代器，也不能直接用增强 for 循环（因为它不是 Collection 的子接口）。我们必须通过**三种“中介”方式**来遍历。

#### 方式一：键找值 (KeySet)

- **思路**：先拿所有的 Key，再通过 `get(key)` 找 Value。
- |方法名称|说明|
  | -------------------------------| ----------------------|
  |public Set\<K\>keySet()|获取所有键的集合|
  |public V get(Object key)|根据键获取其对应的值|
- ```java
  代码：// 1. 获取所有键的 Set 集合
  Set<String> keys = map.keySet();
  // 2. 遍历键
  for (String key : keys) {
      // 3. 根据键找值
      Integer value = map.get(key);
      System.out.println(key + " = " + value);
  }
  ```

#### 方式二：键值对对象 (EntrySet) —— *效率最高*

- **思路**：直接把 map 里的“键值对”作为一个整体 (`Map.Entry` 对象) 取出来。
- |Map**提供的方法**|说明|
  | ------------------------------------------------| --------------------------|
  |Set\<Map.Entry\<K, V\>\>entrySet()|获取所有“键值对”的集合|
- |Map.Entry**提供的方法**|说明|
  | -------------| --------|
  |KgetKey()|获取键|
  |VgetValue()|获取值|
- ​**优点**​：一次取出一对，不用回查，大数据量下​**效率优于方式一**。
- ```java
  代码：// 1. 获取所有键值对对象的 Set 集合
  Set<Map.Entry<String, Integer>> entries = map.entrySet();
  // 2. 遍历 Entry 对象
  for (Map.Entry<String, Integer> entry : entries) {
      String key = entry.getKey();
      Integer value = entry.getValue();
      System.out.println(key + " = " + value);
  }
  ```

#### 方式三：Lambda 表达式 (JDK 8+) —— *最优雅*

- |方法名称|说明|
  | ----------------------------------------------------------------------| -----------------------|
  |default voidforEach(BiConsumer\<? super K, ? super V\> action)|结合lambda遍历Map集合|

- ```java
  //代码：//
  map.forEach((k, v) -> {
      System.out.println(k + " = " + v);
  });
  ```

---

### 🏭 4. Map 集合的实现类 (Implementation Classes)

这些实现类的特点，跟我们刚才学的 Set 集合​**一模一样**（因为 HashSet 底层就是 HashMap，TreeSet 底层就是 TreeMap）。

#### A. HashMap (最常用)

- ​**特点**：

  - ​**无序**、不重复（指 Key）、无索引。
  - ​**允许 null**​：可以存一个 `null`​ 键和多个 `null` 值。
- ​**底层原理**​：​**哈希表**（JDK 8: 数组 + 链表 + 红黑树）。

  - ​*回顾*​：依赖 Key 的 `hashCode()`​ 和 `equals()` 方法去重。

#### B. LinkedHashMap

- ​**特点**​：​**有序**（保证存取顺序）、不重复（指 Key）、无索引。
- ​**底层原理**​：哈希表 + ​**双向链表**（维护插入顺序）。

#### C. TreeMap

- ​**特点**​：​**可排序**（按 Key 的大小）、不重复（指 Key）、无索引。
- ​**底层原理**​：​**红黑树**。
- ​**排序规则**：

  - Key 必须实现 `Comparable` 接口。
  - 或者创建 TreeMap 时传入 `Comparator` 比较器。

---

### 🆚 总结对比

|**实现类**|**Key 的有序性**|**Key 的数据结构**|**应用场景**|||||
| --| --| -------------------| ---------------------------------------| --| --| --| --|
|**HashMap**|**无序**|哈希表|​**90% 的场景**。增删改查性能最快。|||||
|**LinkedHashMap**|**插入有序**|哈希表 + 双向链表|需要 Key 按照存入顺序排列时。|||||
|**TreeMap**|**排序 (升序/降序)**|红黑树|需要 Key 按照数值大小或字典序排列时。|||||

​**复习小贴士**：

学习 Map 的时候，不要把它当成新知识，**把它当成“带了 Value 拖油瓶”的 Set** 就可以了。逻辑完全互通！

‍

---

# Stream流:

**简单来说，Stream 就是一条**“数据流水线”**。**

---

### 🌊 1. 什么是 Stream 流？

- ​**核心思想**：

  - ​**不存数据**：Stream 不像 List 那样存储数据，它只是负责搬运和处理数据。
  - ​**不改变源**​：Stream 在处理过程中，**不会修改**原始集合中的数据，而是生成新的结果。
  - ​**流水线作业**​：由  **“数据源 ->**  **中间操作 ->**  **终结操作”**  三步组成。
- ​**一句话概括**：Stream 结合 Lambda 表达式，可以让我们像写 SQL 语句一样去操作 Java 集合（比如过滤、排序、映射）。

---

### 🛠️ 2. Stream 流的三步走 (标准范式)

不管多复杂的流操作，永远逃不出这三步：

1. **获取流** (Source)：把集合、数组变成流。
2. **中间操作** (Intermediate)：流水线加工（过滤、排序、去重...），支持链式编程。
3. **终结操作** (Terminal)：出结果（转成 List、打印、统计数量）。

> ​**注意**​：中间操作是**懒加载 (Lazy)**  的。如果没有终结操作，中间操作​**一行都不会执行**！

---

### ⚡ 3. 常用 API 速查表

#### 第一步：获取流

- ​**Collection (List/Set)** ​: `list.stream()`
- ​**Map**: 必须先转成单列才能流化。

  - ​`map.keySet().stream()`
  - ​`map.entrySet().stream()`
- ​**数组**​: `Arrays.stream(arr)`​ 或 `Stream.of(arr)`

#### 第二步：中间操作 (加工)

|**方法名**|**说明**|**示例**||||
| ------| ----------------------------| -----------------| --| --| --|
|​`filter(Predicate)`|​**过滤**：保留符合条件的数据|​`filter(s -> s.startsWith("张"))`||||
|​`map(Function)`|​**转换**：把 A 类型变成 B 类型|​`map(s -> Integer.parseInt(s))`||||
|​`sorted()`|**排序**|​`sorted()`​(自然) 或`sorted(Comparator)`||||
|​`distinct()`|**去重**(依赖 hashCode/equals)|​`distinct()`||||
|​`limit(long n)`|**截取**前 n 个|​`limit(3)`||||
|​`skip(long n)`|**跳过**前 n 个|​`skip(2)`||||

#### 第三步：终结操作 (结果)

|**方法名**|**说明**|**示例**||||
| ------| ---------------------| ------| --| --| --|
|​`forEach(Consumer)`|**遍历**|​`forEach(s -> System.out.println(s))`||||
|​`count()`|**统计**个数|​`long count = stream.count();`||||
|​`collect(Collector)`|**收集**(转回集合) 🔥最常用|​`collect(Collectors.toList())`||||

---

### 💻 4. 代码实战对比

​**需求**：有一个名字列表，找出所有“姓张”且“名字是 3 个字”的人，打印出来。

#### ❌ 老写法 (For 循环)

Java

```
List<String> list = Arrays.asList("张无忌", "周芷若", "张三丰", "赵敏", "张三");
List<String> zhangList = new ArrayList<>();

for (String name : list) {
    if (name.startsWith("张") && name.length() == 3) {
        zhangList.add(name);
    }
}
for (String name : zhangList) {
    System.out.println(name);
}
```

#### ✅ 新写法 (Stream 流)

Java

```
List<String> list = Arrays.asList("张无忌", "周芷若", "张三丰", "赵敏", "张三");

list.stream()
    .filter(name -> name.startsWith("张")) // 1. 过滤姓张
    .filter(name -> name.length() == 3)    // 2. 过滤3个字
    .forEach(name -> System.out.println(name)); // 3. 终结：打印
// 甚至可以用方法引用： .forEach(System.out::println);
```

---

### 🧩 5. Map 方法 (映射)【难点】与全流程总结

以下涵盖了 Stream 流的 **获取**、**中间操作**、**终结操作** 以及 **相关实体类配置** 四大核心板块。

---

# 🌊 Java Stream 流学习笔记

Stream 流是 Java 8 引入的特性，它就像一条​**流水线**，用于操作集合或数组中的数据（过滤、排序、映射、收集等）。

​**核心思想**：不改变源数据，而是生成新的结果。

---

## 1️⃣ 获取 Stream 流的方式 (StreamDemo2)

Stream 流主要针对 Collection 集合、Map 集合和数组。

### 1. Collection 单列集合

直接调用集合提供的 `.stream()` 方法。

Java

```
Collection<String> list = new ArrayList<>();
Stream<String> s1 = list.stream();
```

### 2. Map 双列集合 (重点)

​**Map 本身没有**  **​`.stream()`​** ​ **方法**，必须先转换成单列集合（Set 或 Collection）才能获取流。

- ​**获取键流**​：`map.keySet().stream()`
- ​**获取值流**​：`map.values().stream()`
- ​**获取键值对流**​：`map.entrySet().stream()`

### 3. 数组 & 散数据

- **数组**：`Arrays.stream(数组名)`​ 或 `Stream.of(数组名)`，

  对于​**基本数据类型的数组**​（`int[]`​, `long[]`​, `double[]`​），千万不要用 `Stream.of()`。

  **请使用以下两种标准写法，直接获取** **​`IntStream`​**​ **：Arrays.stream (最常用)，IntStream.of**
- **散数据**：`Stream.of("数据1", "数据2", ...)`

  ‍

---

## 2️⃣ 常用中间方法 (StreamDemo3)

中间操作会返回一个新的 Stream 流，支持​**链式编程**。

|**方法名**|**说明**|**代码示例**||||
| ------| -------------------------------| --------------------------------| --| --| --|
|​**​`filter`​**|​**过滤**：保留符合条件的数据|​`list.stream().filter(s -> s.startsWith("张"))`||||
|​**​`sorted`​**|​**排序**：默认升序或自定义比较器|1. 默认:`.sorted()`<br /><br />2. 降序:`.sorted((s1, s2) -> Double.compare(s2, s1))`||||
|​**​`limit`​**|​**截取**：保留前 n 个|​`.limit(2)`||||
|​**​`skip`​**|​**跳过**：跳过前 n 个|​`.skip(2)`||||
|​**​`distinct`​**|​**去重**：依赖 hashCode 和 equals|​`.distinct()`(需重写对象方法)||||
|​**​`map`​**|​**映射/加工**：把一种数据变成另一种|​`.map(s -> "加工后:" + s)`​(如 Teacher -\> String)||||
|​**​`concat`​**|​**合并**：将两个流合并为一个|​`Stream.concat(s1, s2)`||||

> ​ **⚠️ 注意**​：`distinct()`​ 去重自定义对象时，该对象类（如 `Teacher`​）必须重写 `hashCode()`​ 和 `equals()` 方法。

---

## 3️⃣ 常用终结方法 (StreamDemo4)

终结操作是流的最后一步，执行后流就**关闭**了，无法再使用。

### 1. 查找与统计

- ​**​`forEach`​**：遍历。
- ​**​`count`​**​：统计符合条件的元素个数，返回 `long`。
- ​**​`max`​**​  **/**  **​`min`​**：获取最大/最小值。

  - 返回的是 `Optional<T>`​ 对象（防止空指针），需要调用 `.get()` 获取真实数据。
  - ```java
    代码示例：// 获取最高薪水的老师
    Optional<Teacher> max = teachers.stream().max((t1, t2) -> Double.compare(t1.getSalary(), t2.getSalary()));
    Teacher maxTeacher = max.get();
    ```

### 2. 收集 (Collect) —— 最重要

将流处理后的结果放回集合中。

- **收集到 List**：
- ```java
  List<String> list = stream.collect(Collectors.toList());
  ```
- **收集到 Set** (自动去重)：
- ```java
  Set<String> set = stream.collect(Collectors.toSet());
  ```
- **收集到 Array**：
- ```java
  Object[] array = stream.toArray();
  ```
- **收集到 Map** (最复杂)：

  ```java

  需要指定谁做 Key，谁做 Value。
  // Key: 名字, Value: 薪水
  Map<String, Double> map = teachers.stream()
      .collect(Collectors.toMap(Teacher::getName, Teacher::getSalary));
  ```

  > ​ **⚠️ 注意**：收集到 Map 时，如果 Key 重复会报错（Duplicate Key）。
  >

---

## 4️⃣ 实体类配合 (Teacher.java)

在使用 Stream 流进行排序时，有两种方式指定规则：

1. ​**内部比较器 (Comparable)** ：

   - 让实体类实现 `Comparable<T>` 接口。
   - 重写 `compareTo` 方法。
   - ​`Stream.sorted()` 无参时默认调用此逻辑。
   - ```java
     @Override
     public int compareTo(Teacher o) {
         return this.getAge() - o.getAge(); // 按年龄升序
     }
     ```
2. ​**外部比较器 (Comparator)** ：

   - 在 Stream 调用时直接传入 Lambda 表达式。
   - 优先级高于内部比较器。
   - ```java
     	stream.sorted((t1, t2) -> Double.compare(t2.getSalary(), t1.getSalary())) // 按薪水降序
     ```

```java
package com.itheima.demo3stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StreamDemo3 {
    public static void main(String[] args) {
        // 目标：掌握Stream提供的常用的中间方法，对流上的数据进行处理（返回新流：支持链式编程）
        List<String> list = new ArrayList<>();
        list.add("张无忌");
        list.add("周芷若");
        list.add("赵敏");
        list.add("张强");
        list.add("张三丰");
        list.add("张翠山");

        // 1、过滤方法
        list.stream().filter(s -> s.startsWith("张") &&  s.length() == 3).forEach(System.out::println);

        // 2、排序方法。
        List<Double> scores = new ArrayList<>();
        scores.add(88.6);
        scores.add(66.6);
        scores.add(66.6);
        scores.add(77.6);
        scores.add(77.6);
        scores.add(99.6);
        scores.stream().sorted().forEach(System.out::println); // 默认是升序。
        System.out.println("--------------------------------------------------");

        scores.stream().sorted((s1, s2) -> Double.compare(s2, s1)).forEach(System.out::println); // 降序
        System.out.println("--------------------------------------------------");

        scores.stream().sorted((s1, s2) -> Double.compare(s2, s1)).limit(2).forEach(System.out::println); // 只要前2名
        System.out.println("--------------------------------------------------");

        scores.stream().sorted((s1, s2) -> Double.compare(s2, s1)).skip(2).forEach(System.out::println); // 跳过前2名
        System.out.println("--------------------------------------------------");

        // 如果希望自定义对象能够去重复，重写对象的hashCode和equals方法，才可以去重复！
        scores.stream().sorted((s1, s2) -> Double.compare(s2, s1)).distinct().forEach(System.out::println); // 去重复

        // 映射/加工方法： 把流上原来的数据拿出来变成新数据又放到流上去。
        scores.stream().map(s -> "加10分后：" + (s + 10)).forEach(System.out::println);

        // 合并流：
        Stream<String> s1 = Stream.of("张三丰", "张无忌", "张翠山", "张良", "张学友");
        Stream<Integer> s2 = Stream.of(111, 22, 33, 44);
        Stream<Object> s3  = Stream.concat(s1, s2);
        System.out.println(s3.count());
    }
}

```

‍

‍

```java
package com.itheima.demo3stream;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamDemo4 {
    public static void main(String[] args) {
        // 目标：掌握Stream流的统计，收集操作（终结方法）
        List<Teacher> teachers = new ArrayList<>();
        teachers.add(new Teacher("张三", 23, 5000));
        teachers.add(new Teacher("金毛狮王", 54, 16000));
        teachers.add(new Teacher("李四", 24, 6000));
        teachers.add(new Teacher("王五", 25, 7000));
        teachers.add(new Teacher("白眉鹰王", 66, 108000));
        teachers.add(new Teacher("陈昆", 42, 48000));

        teachers.stream().filter(t -> t.getSalary() > 15000).forEach(System.out::println);

        System.out.println("--------------------------------------------------");

        long count = teachers.stream().filter(t -> t.getSalary() > 15000).count();
        System.out.println(count);

        System.out.println("--------------------------------------------------");

        // 获取薪水最高的老师对象
        Optional<Teacher> max = teachers.stream().max((t1, t2) -> Double.compare(t1.getSalary(), t2.getSalary()));
        Teacher maxTeacher = max.get(); // 获取Optional对象中的元素
        System.out.println(maxTeacher);

        Optional<Teacher> min = teachers.stream().min((t1, t2) -> Double.compare(t1.getSalary(), t2.getSalary()));
        Teacher minTeacher = min.get(); // 获取Optional对象中的元素
        System.out.println(minTeacher);

        System.out.println("---------------------------------------------------------");

        List<String> list = new ArrayList<>();
        list.add("张无忌");
        list.add("周芷若");
        list.add("赵敏");
        list.add("张强");
        list.add("张三丰");
        list.add("张三丰");
        list.add("张翠山");

        // 流只能收集一次

        // 收集到集合或者数组中去。
        Stream<String> s1 = list.stream().filter(s -> s.startsWith("张"));
        // 收集到List集合
        List<String> list1 = s1.collect(Collectors.toList());
        System.out.println(list1);

//        Set<String> set2 = new HashSet<>();
//        set2.addAll(list1);

        // 收集到Set集合
        Stream<String> s2 = list.stream().filter(s -> s.startsWith("张"));
        Set<String> set = s2.collect(Collectors.toSet());
        System.out.println(set);

        // 收集到数组中去
        Stream<String> s3 = list.stream().filter(s -> s.startsWith("张"));
        Object[] array = s3.toArray();
        System.out.println("数组：" + Arrays.toString(array));

        System.out.println("------------------收集到Map集合---------------------------");

        // 收集到Map集合：键是老师名称，值是老师薪水
        Map<String, Double> map = teachers.stream().collect(Collectors.toMap(Teacher::getName, Teacher::getSalary));
        System.out.println(map);
    }
}

```

---

‍

## 💡 核心总结 

1. ​**流是一次性的**​：流经过终结方法（如 `collect`​, `count`​, `forEach`​）后，就被关闭了。​**不能拿着同一个流对象重复调用**。
2. ​**不改变源数据**​：Stream 操作生成的都是新数据，原来的 `list`​ 或 `map` 内容不会变。
3. ​**Lombok 使用**​：`@Data`​ 自动生成了 getter/setter/toString/hashCode/equals，这对于 `distinct()` 去重至关重要。

---

‍
