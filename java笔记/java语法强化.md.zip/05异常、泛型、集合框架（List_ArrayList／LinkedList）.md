# 05异常、泛型、集合框架（List|ArrayList／LinkedList）

### 1. 认识异常 (Understanding Exceptions)

异常（Exception）是指程序在执行过程中出现的非正常情况。在 Java 中，异常也是对象。

#### 异常的继承体系

所有的异常都来自于共同的祖先 `Throwable`。

**两大分类：**

1. ​**Error (错误)** ：

   - 代表​**系统级别的严重错误**​（如内存溢出 `OutOfMemoryError`​，栈溢出 `StackOverflowError`）。
   - **特点**：这是“绝症”，通常代码无法修复，**不需要捕获**。
   - Error：代表的系统级别错误(属于严重问题)，也就是说系统一旦出现问题，sun公司会把这些问题封装成Error对象给出来  
     ( 说白了，Error是给sun公司自己用的，不是给我们程序员用的，因此我们开发人员不用管它)
2. ​**Exception (异常)** ：

   - 代表​**程序可能出现的问题**，是我们处理的核心。
   - 它又分为两类（这是面试必考点）：

     编译时异常：没有继承RuntimeExcpetion的异常，编译阶段就会出错。  
     运行时异常：继承自RuntimeException的异常或其子类，编译阶段不报错，运行时出现的。

|**类型**|**名字**|**举例**|**特点**|**处理原则**||||||
| --| -------------------| ------------| ------------------------------------------| ------------------------| --| --| --| --| --|
|**编译时异常**|Checked Exception|​`IOException`​,`SQLException`​,`ClassNotFoundException`|编译器**强制**要求处理，否则​**代码爆红**，编译不通过。|**必须**try-catch 或 throws||||||
|**运行时异常**|RuntimeException|​`NullPointerException`​,`IndexOutOfBoundsException`​,`ArithmeticException`|编译器不报错，运行时才报错。通常是​**代码逻辑写错了**。|**建议**不处理，而是改代码逻辑||||||

---

### 2. 异常的处理方案 (Handling Schemes)

当异常发生时，我们有两种应对策略： **“自己解决”**  和 ​ **“甩锅给别人”** 。

#### 方案 A：捕获异常 (try-catch) —— "我自己处理"

- ​**作用**：拦截异常，保证程序不崩溃，后续代码能继续执行。
- **格式**：
- ```java
  try {
      // 可能出现异常的代码
      int result = 10 / 0; 
  } catch (ArithmeticException e) {
      // 出现异常后的补救措施
      System.out.println("算术算错了，除数不能为0");
      e.printStackTrace(); // 打印详细错误信息 (开发必写)
  } finally {
      // 【可选】无论是否异常，都会执行 (通常用于释放资源，如关闭文件/数据库)
      System.out.println("资源释放");
  }
  ```

#### 方案 B：抛出异常 (throws) —— "甩锅给调用者"

- ​**作用**：我不处理，我把异常抛给调用我的那个人去处理。
- **格式**：在方法定义上使用 `throws` 关键字。
- ## （直接抛父类exception即可）!!!(多态)
- ```java
  // 意思是：我这个方法可能会出文件找不到的问题，谁调用我谁负责处理
  public void readFile() throws FileNotFoundException（直接抛父类exception即可） {
      FileInputStream is = new FileInputStream("不存在的文件.txt");
  }
  ```

 **🤔 到底用哪种？**

- ​**底层方法**​（比如工具类）：通常用 ​**throws**，抛出去告诉上层发生了什么。
- ​**顶层方法**​（比如 `main`​ 方法或 Controller）：通常用 ​**try-catch**，因为没人可甩了，必须最终解决掉，给用户一个友好的提示。

---

### 3. 自定义异常 (Custom Exceptions)

**为什么要自定义？**

Java 提供的异常（如 `IndexOutOfBoundsException`）是通用的，但由于业务逻辑（如“银行卡余额不足”、“用户未满18岁”）Java 无法预知，所以我们需要定义符合业务含义的异常。

#### 实现步骤

1. ​**定义一个类**​：通常以 `Exception` 结尾。
2. ​**继承父类**：

   - 继承 `RuntimeException`​ (​**推荐**)：变成运行时异常，使用更灵活，不需要到处写 throws。
   - 继承 `Exception`：变成编译时异常，强迫调用者处理。
3. ​**构造器**​：调用父类的构造器 `super(message)`。

#### 代码示例：检查年龄

Java

```
// 1. 定义异常类 (继承 RuntimeException)
class AgeIllegalException extends RuntimeException {
    public AgeIllegalException(String message) {
        super(message); // 把错误信息交给父类处理
    }
}

// 2. 业务代码
public class ExceptionDemo {
    public static void checkAge(int age) {
        if (age < 0 || age > 200) {
            // 3. 这里的 throw 是动作：抛出一个异常对象
            throw new AgeIllegalException("年龄不合法！怎么可能是 " + age + " 岁？");
        }
        System.out.println("年龄登记成功：" + age);
    }

    public static void main(String[] args) {
        try {
            checkAge(300); // 故意传入错误年龄
        } catch (Exception e) {
            e.printStackTrace(); // 打印我们在上面写的错误信息
        }
    }
}
```

---

### ⚠️ 两个关键字的区别 (高频易混淆)

请一定在笔记里把这两个词区分开：

- ​**​`throw`​**​ (动词)：用在​**方法内**，创建一个异常对象并抛出。

  - *例子：*  `throw new RuntimeException("错了");`
- ​**​`throws`​**​ (名词/声明)：用在​**方法签名上**，声明这个方法可能会丢出什么异常。

  - *例子：*  `public void method() throws Exception { ... }`

---

# 泛型：

泛型（Generics）是 Java 5 引入的特性，它是 Java 编程中“安全”和“规范”的基石。简单来说，​**泛型就是给类或方法贴上一个“类型标签”** 。

---

### 🏷️ 1. 认识泛型 (Understanding Generics)

​**核心概念**：

泛型本质上是**参数化类型**。我们在定义类或方法时，不把数据类型写死，而是用一个变量（如 `<T>、<E>、<K> 、<V>`）来代替，等到真正使用的时候再指定具体类型。

**为什么要用泛型？**

1. **编译时检查**：在写代码时就能发现类型错误，而不是等到运行时报 `ClassCastException`（类型转换异常）。泛型提供了在编译阶段约束所能操作的数据类型，并自动进行检查的能力！

1. ​**避免强制转换**​：取数据时不需要手动 `(String)` 强转，代码更干净。

**代码对比：**

Java

```
// ❌ 没有泛型：不安全
ArrayList list = new ArrayList();
list.add("Java");
list.add(100); // 居然能存整数，太乱了
String s = (String) list.get(1); // 运行时报错：ClassCastException

// ✅ 有了泛型：安全
ArrayList<String> list = new ArrayList<>();
list.add("Java");
// list.add(100); // 编译直接报错！红线提示你
String s = list.get(0); // 不需要强转
```

---

### 🧱 2. 泛型支持的类型 (Supported Types)

这是一个非常重要的面试考点：

> **泛型不支持基本数据类型，只支持引用数据类型。**

- ❌ `ArrayList<int>`
- ❌ `ArrayList<double>`
- ✅ `ArrayList<Integer>`
- ✅ `ArrayList<Double>`

​**原因**：

Java 的泛型是**伪泛型**，编译后会进行**类型擦除**（Type Erasure），所有的泛型信息都会被擦除为 `Object`​。而 `Object`​ 无法存储 `int`​ 这种基本类型，所以必须使用**包装类**。object = int？显然是不行的。所以需要采用包装类，java通过包装类，将基本数据类型封装为object类（object是所有类的祖宗类）。

---

### 🏭 3. 泛型类 (Generic Class)

​**定义**​：在类名后面跟上 `<类型变量>`。

​**常用符号**​：`T`​ (Type), `E`​ (Element), `K`​ (Key), `V` (Value)。

​**格式**：

Java

```java
// 定义一个可以存任何类型的盒子
public class Box<T> {
    private T content;

    public void setContent(T content) {
        this.content = content;
    }

    public T getContent() {
        return content;
    }
}
```

​**使用**：

Java

```java
// T 变成了 String
Box<String> stringBox = new Box<>();
stringBox.setContent("礼物");

// T 变成了 Integer
Box<Integer> intBox = new Box<>();
intBox.setContent(666);
```

---

### 🔌 4. 泛型接口 (Generic Interface)

​**定义**​：与泛型类类似，在接口名后加 `<E>`。

Java

```java
public interface Data<E> {
    void add(E e);
    E get(int index);
}
```

​**实现方式有 2 种**：

1. ​**实现类也不确定类型**（继续泛型）：
2. ​**实现类确定类型**（把泛型定死）：

---

### 🔧 5. 泛型方法 (Generic Method)

​**核心区别**：

泛型方法定义的泛型类型，​**只在当前方法有效**。它甚至可以在一个普通类（非泛型类）中定义。

​**格式**​：​ **​`<T>`​** ​ **必须放在返回值类型之前**。

Java

```java
public class Test {
    // 这是一个泛型方法
    // <T> 声明这是一个泛型方法，T 是参数类型，void 是返回值
    public <T> void printArray(T[] arr) {
        for (T t : arr) {//强化for循环
            System.out.println(t);
        }
    }
}
```

---

### 🃏 6. 通配符与上下限 (Wildcards & Bounds)

这是泛型中最难理解的部分，主要解决 `List<Object>`​ 不是 `List<String>` 的父类的问题。（说人话就是我有两个类，我想要装这两个类的ArrayList<t>,但是我想用父类car去接收,这显然是不现实的，因为不是一个东西。所以就用通配符和上下限去解决我要去装自定义类的情况。）

#### 1. 通配符 `?`

代表“任意类型”。通常用于**方法的参数**中。

Java

```
// 可以接收 ArrayList<String> 也可以接收 ArrayList<Integer>
public void go(ArrayList<?> list){
}
```

#### 2. 上限 (extends)

- ​**格式**​：`? extends Car`
- ​**含义**​：只能接收 `Car`​ 或者 `Car`​ 的​**子类**。
- ​**作用**：限定了“天花板”。

#### 3. 下限 (super)

- ​**格式**​：`? super Car`
- ​**含义**​：只能接收 `Car`​ 或者 `Car`​ 的​**父类**。
- ​**作用**：限定了“地板”。

#### ⚠️ 一个简单的记忆技巧

- ​**​`ArrayList<Object>`​** ​ **和** **​`ArrayList<String>`​** ​ **没有继承关系！**  它们是半毛钱关系都没有的两个类。
- 如果想让一个方法能同时处理它们，必须用通配符 `?`。

### 💡 总结笔记

1. ​**本质**：给代码加标签，为了编译安全。
2. ​**类型**​：只能用引用类型 (`Integer`​), 不能用基本类型 (`int`)。
3. ​**定义**​：类 `<T>`​, 接口 `<E>`​, 方法 `public <T> void ...`。
4. **通配符**：`?`​ 代表一切，`extends`​ 规定上限，`super` 规定下限。
5. **包装类：**

|基本数据类型|对应的包装类（引用数据类型）|
| --------------| ------------------------------|
|byte|Byte|
|short|Short|
|int|Integer|
|long|Long|
|char|Character|
|float|Float|
|double|Double|
|boolean|Boolean|

```java
package com.itheima.demo4genericity;

import java.util.ArrayList;

public class GenericDemo5 {
    public static void main(String[] args) {
        // 目标：理解通配符和上下限。
        ArrayList<Xiaomi> xiaomis = new ArrayList<>();
        xiaomis.add(new Xiaomi());
        xiaomis.add(new Xiaomi());
        xiaomis.add(new Xiaomi());
        go(xiaomis);

        ArrayList<BYD> byds = new ArrayList<>();
        byds.add(new BYD());
        byds.add(new BYD());
        byds.add(new BYD());
        go(byds);

//        ArrayList<Dog> dogs = new ArrayList<>();
//        dogs.add(new Dog());
//        dogs.add(new Dog());
//        dogs.add(new Dog());
//        go(dogs);
    }

    // 需求：开发一个极品飞车的游戏。
    // 虽然Xiaomi和BYD是Car的子类，但是 ArrayList<Xiaomi>  ArrayList<BYD>和 ArrayList<Car> 是没有半毛钱关系！
    public static void go(ArrayList<? extends Car> cars) {
    }
}

```

---

```java
package com.itheima.demo5genericity;

import java.util.ArrayList;

public class GenericDemo6 {
    public static void main(String[] args) {
        // 目标：搞清楚泛型和集合不支持基本数据类型，只能支持对象类型（引用数据类型）。
        // ArrayList<int> list = new ArrayList<>();
        // 泛型擦除：泛型工作在编译阶段，等编译后泛型就没用了，所以泛型在编译后都会被擦除。所有类型会恢复成Object类型

        // 把基本数据类型变成包装类对象。
        // 手工包装:
        // Integer i = new Integer(100); // 过时
        Integer it1 = Integer.valueOf(100);  // 推荐的
        Integer it2 = Integer.valueOf(100);  // 推荐的
        System.out.println(it1 == it2);

        // 自动装箱成对象：基本数据类型的数据可以直接变成包装对象的数据，不需要额外做任何事情
        Integer it11 = 130;
        Integer it22 = 130;
        System.out.println(it11 == it22);

        // 自动拆箱：把包装类型的对象直接给基本类型的数据
        int i = it11;
        System.out.println(i);

        ArrayList<Integer> list = new ArrayList<>();
        list.add(130);  // 自动装箱
        list.add(120);  // 自动装箱
        int rs = list.get(1); // 自动拆箱

        System.out.println("-----------------------------------------------------------------------");

        // 包装类新增的功能：
        // 1、把基本类型的数据转换成字符串。
        int j = 23;
        String rs1 = Integer.toString(j);   // "23"
        System.out.println(rs1 + 1); // 231

        Integer i2 = j;
        String rs2 = i2.toString(); // "23"
        System.out.println(rs2 + 1 ); // 231

        String rs3 = j + "";
        System.out.println(rs3 + 1 ); // 231

        System.out.println("-----------------------------------------------------------------------");

        // 2、把字符串数值转换成对应的基本数据类型（很有用）。
        String str = "98";
        // int i1 = Integer.parseInt(str);
        int i1 = Integer.valueOf(str);
        System.out.println(i1 + 2);

        String str2 = "98.8";
//        double d = Double.parseDouble(str2);
        double d = Double.valueOf(str2);
        System.out.println(d + 2);
    }
}

```

---

# 集合框架：

![image](assets/image-20260206221342-0ab1n4g.png)

---

### 📦 1. 认识集合 (Introduction)

**什么是集合？**

集合是 Java 提供的一种​**容器**，用来存储多个数据。

**核心考点：集合 vs 数组**

|**特性**|**数组 (Array)**|**集合 (Collection)**||||
| --| ----------------------| --------------------------------| --| --| --|
|**长度**|**固定不可变**|**可变**(自动扩容)||||
|**存储内容**|基本类型 或 引用类型|**只能存引用类型**(int要变Integer)||||
|**适用场景**|数据个数确定时|数据个数不确定，或需频繁增删时||||

**集合体系图解 (简化版)：**

Java 集合主要分为两大派系：

1. ​**Collection (单列集合)** ：一个一个地存数据。

   - ​`List` (有序、可重复、有索引)【有索引，所以有序且可重复。类似于数组。】
   - ​`Set` (无序、不重复、无索引)【无索引，所以无序且不可重复。】
2. ​**Map (双列集合)** ：一对一对地存数据 (Key-Value)。

---

### 🛠️ 2. Collection 的功能 (Common Methods)

​`Collection<E>`​ 是所有单列集合（List 和 Set）的​**顶层接口**。它里面定义的方法，是所有单列集合通用的。

**常用 API 速查表：**

|**方法名**|**说明**|**示例**||||
| ------| --------------| ------------------------------------| --| --| --|
|​`add(E e)`|添加元素|​`coll.add("Java");`(List总返回true，Set可能false)||||
|​`clear()`|清空集合|​`coll.clear();`||||
|​`remove(E e)`|删除指定元素|​`coll.remove("Java");`(删除成功返回 true)||||
|​`contains(E e)`|判断是否包含|​`coll.contains("Java");`||||
|​`isEmpty()`|判断是否为空|​`coll.isEmpty();`||||
|​`size()`|获取元素个数|​`coll.size();`||||
|​`toArray()`|转成数组|​`Object[] arr = coll.toArray();`||||

> **注意**：Collection 接口中**没有**根据索引操作的方法（如 `get(i)`），因为 Set 集合是没有索引的。

```java
package com.itheima.demo6collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.function.IntFunction;

public class CollectionDemo2 {
    public static void main(String[] args) {
        // 目标：搞清楚Collection提供的通用集合功能。
        Collection<String> list = new ArrayList<>();

        // 添加元素
        list.add("张三");
        list.add("李四");
        list.add("王五");
        System.out.println(list); // [张三, 李四, 王五]

        // 获取集合的元素个数
        System.out.println(list.size());

        // 删除集合元素
        list.remove("李四");
        System.out.println(list);

        // 判断集合是否为空
        System.out.println(list.isEmpty()); // false

        // 清空集合
        // list.clear();
        // System.out.println(list);

        // 判断集合中是否存在某个数据
        System.out.println(list.contains("张三"));

        // 把集合转换成数组
        Object[] arr = list.toArray();
        System.out.println(Arrays.toString(arr));

        // 把集合转换成字符串数组(拓展)
        String[] arr2 = list.toArray(String[]::new);
    }
}

```

# Collection的遍历方式：

## 1.迭代器遍历：

- 迭代器是用来遍历集合的专用方式(数组没有迭代器)，在Java中迭代器的代表是Iterator。
- #### Collection集合获取迭代器的方法:

  |方法名称|说明|
  | ---------------------| -------------------------------------------------------------------------------------------|
  |Iterator\<E\>**iterator()**|返回集合中的迭代器对象，该迭代器对象默认指向当前集合的第一个元素(默认指向当前集合的索引0)|
- #### Iterator迭代器中的常用方法:

  |方法名称|说明|
  | -------------------| -----------------------------------------------------------|
  |boolean hasNext()|询问当前位置是否有元素存在，存在返回true ,不存在返回false|
  |E next()|获取当前位置的元素，并同时将迭代器对象指向下一个元素处。|
- #### 2、通过迭代器获取集合的元素，如果取元素越界会出现什么异常?

  会出现NoSuchElementException异常。

```java
package com.itheima.demo6collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class CollectionTraversalDemo3 {
    public static void main(String[] args) {
        // 目标：掌握Collection的遍历方式一：迭代器遍历
        ArrayList<String> names = new ArrayList<>();
        names.add("张无忌");
        names.add("玄冥二老");
        names.add("宋青书");
//        names.add("殷素素");
        System.out.println(names); // [张无忌, 玄冥二老, 宋青书]
        //                                                      it

        // 1、得到这个集合的迭代器对象
        Iterator<String> it = names.iterator();
//        System.out.println(it.next());
//        System.out.println(it.next());
//        System.out.println(it.next());
//        System.out.println(it.next());
//        System.out.println(it.next()); // NoSuchElementException

        // 2、使用一个while循环来遍历
        while (it.hasNext()) {
            String name = it.next();
            System.out.println(name);
        }
    }
}

```

## 2.增强FOR循环：

- FOR循环格式：

- ```java
  for (元素的数据类型 变量名 : 数组或者集合) { 
  }
  ```
- **增强for可以用来遍历集合或者数组。
  增强for遍历集合，本质就是迭代器遍历集合的简化写法。**
- ## 案例：

```java
package com.itheima.demo6collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class CollectionTraversalDemo4 {
    public static void main(String[] args) {
        // 目标：掌握Collection的遍历方式二：增强for
        Collection<String> names = new ArrayList<>();
        names.add("张无忌");
        names.add("玄冥二老");
        names.add("宋青书");
        names.add("殷素素");

        for (String name : names) {
            System.out.println(name);
        }

        String[] users = {"张无忌", "玄冥二老", "宋青书", "殷素素"};

        for (String user : users) {
            System.out.println(user);
        }
    }
}

```

## 3.Lambda：

```java
package com.itheima.demo6collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.function.Consumer;

public class CollectionTraversalDemo5 {
    public static void main(String[] args) {
        // 目标：掌握Collection的遍历方式三：lambda
        Collection<String> names = new ArrayList<>();
        names.add("张无忌");
        names.add("玄冥二老");
        names.add("宋青书");
        names.add("殷素素");


//        names.forEach(new Consumer<String>() {
//            @Override
//            public void accept(String s) {
//                System.out.println(s);
//            }
//        });

//        names.forEach(s -> System.out.println(s));
//@FunctionalInterface   consumer 是一个函数式接口，所以采用lambda表达式简化，同时是
// 1. Lambda 标准写法
// System.out 是一个已经存在的 PrintStream 对象
//list.forEach(s -> System.out.println(s));
//public interface Consumer<T> {}
        names.forEach(System.out::println);
    }
}

```

# 并发修改异常问题：

- 遍历集合的同时又存在增删集合元素的行为时可能出现业务异常，这种现象被称之为并发修改异常问题。

```java
package com.itheima.demo6collection;

import java.util.ArrayList;
import java.util.Iterator;

public class CollectionTraversalTest6 {
    public static void main(String[] args) {
        // 目标：认识并发修改异常问题，搞清楚每种遍历的区别
        ArrayList<String> list = new ArrayList<>();
        list.add("Java入门");
        list.add("宁夏枸杞");
        list.add("黑枸杞");
        list.add("人字拖");
        list.add("特级枸杞");
        list.add("枸杞子");
        list.add("西洋参");
        System.out.println(list);

        // 需求1：删除全部枸杞
        for (int i = 0; i < list.size(); i++) {
            String name = list.get(i);
            if(name.contains("枸杞")){
                list.remove(name);
            }
        }
        System.out.println(list);   //出现并发修改异常问题。
        // [Java入门, 宁夏枸杞, 黑枸杞, 人字拖, 特级枸杞, 枸杞子, 西洋参]
        // [Java入门, 黑枸杞, 人字拖, 枸杞子, 西洋参]
        //           i
        // [Java入门, 黑枸杞, 人字拖, 枸杞子, 西洋参]

        System.out.println("=====================================================");

        ArrayList<String> list2 = new ArrayList<>();
        list2.add("Java入门");
        list2.add("宁夏枸杞");
        list2.add("黑枸杞");
        list2.add("人字拖");
        list2.add("特级枸杞");
        list2.add("枸杞子");
        list2.add("西洋参");
        System.out.println(list2);

        // 需求1：删除全部枸杞
        for (int i = 0; i < list2.size(); i++) {
            String name = list2.get(i);
            if(name.contains("枸杞")){
                list2.remove(name);
                i--; // 解决方案1：删除数据后做一步i--操作 （前提是支持索引）
            }
        }
        // [Java入门, 宁夏枸杞, 黑枸杞, 人字拖, 特级枸杞, 枸杞子, 西洋参]
        // [Java入门, 人字拖,  西洋参]
        //                  i
        System.out.println(list2);

        System.out.println("=====================================================");

        ArrayList<String> list3 = new ArrayList<>();
        list3.add("Java入门");
        list3.add("宁夏枸杞");
        list3.add("黑枸杞");
        list3.add("人字拖");
        list3.add("特级枸杞");
        list3.add("枸杞子");
        list3.add("西洋参");
        System.out.println(list3);

        // 需求1：删除全部枸杞
        // 解决方案2：倒着遍历并删除（前提是支持索引）
        for (int i = list3.size() - 1; i >= 0; i--) {
            String name = list3.get(i);
            if(name.contains("枸杞")){
                list3.remove(name);
            }
        }
        // [Java入门, 人字拖, 西洋参]
        //     i
        System.out.println(list3);

        System.out.println("=====================================================");
        ArrayList<String> list4 = new ArrayList<>();
        list4.add("Java入门");
        list4.add("宁夏枸杞");
        list4.add("黑枸杞");
        list4.add("人字拖");
        list4.add("特级枸杞");
        list4.add("枸杞子");
        list4.add("西洋参");
        System.out.println(list4);

        // 需求1：删除全部枸杞
        // 方案一：迭代器遍历并删除默认也存在并发修改异常问题。
        // 可以解决，解决方案3：使用迭代器自己的方法来删除
        Iterator<String> it = list4.iterator();
        while(it.hasNext()){
            String name = it.next();
            if(name.contains("枸杞")){
                it.remove();   // 可以解决 解决方案3：使用迭代器自己的方法来删除当前数据
            }
        }
        System.out.println(list4);

        System.out.println("=====================================================");

        ArrayList<String> list5 = new ArrayList<>();
        list5.add("Java入门");
        list5.add("宁夏枸杞");
        list5.add("黑枸杞");
        list5.add("人字拖");
        list5.add("特级枸杞");
        list5.add("枸杞子");
        list5.add("西洋参");
        System.out.println(list5);

        // 需求1：删除全部枸杞
        // 方案二和三：用增强for还有Lambda(都没有办法解决并发修改异常问题)
        // 结论：增强for和Lambda只适合做遍历，不适合做遍历并修改操作
//        for (String s : list5) {
//            if(s.contains("枸杞")){
//                list5.remove(s);
//            }
//        }

        // Lambda
//        list5.forEach(s -> {
//            if(s.contains("枸杞")){
//                list5.remove(s);
//            }
//        });
        System.out.println(list5);
    }
}

```

- ## 解决并发修改异常问题的方案:

  **如果集合支持索引**，可以使用for循环遍历，每删除数据后做i--；或者可以倒着遍历  
  可以使用**迭代器遍历**，并用迭代器提供的删除方法删除数据。
- ## **注意!** ：

  增强for循环/Lambda遍历均**不能解决**并发修改异常问题，因此增它们只适合做数据的遍历，不适合同时做增删操作。

---

### 📜 3. List 集合 (List Interface)

> Collection List 和Map都是接口，ArrayList和LinkedList都是实现类

**List 的三大特征 (背诵全文)：**

1. **有序** (Ordered)：存进去是什么顺序，取出来就是什么顺序。
2. **有索引** (Indexed)：可以通过下标 `index` 精确操作元素。
3. **可重复** (Duplicates)：允许存储相同的元素。

**List 独有的方法 (因为有索引)：**

List 继承了 Collection 的全部方法，还增加了一套**带索引**的方法：

- ​`void add(int index, E element)`: 插队，在指定位置插入。
- ​`E remove(int index)`: 删除指定位置的元素，返回被删的元素。
- ​`E set(int index, E element)`: 修改指定位置的元素，返回修改前的旧值。
- ​`E get(int index)`​: **最常用**，获取指定位置的元素。

- |方法名称|说明|
  | -----------------------------| ----------------------------------------|
  |void add(intindex,Eelement)|在此集合中的指定位置插入指定的元素|
  |E remove(int index)|删除指定索引处的元素，返回被删除的元素|
  |E set(intindex,Eelement)|修改指定索引处的元素，返回被修改的元素|
  |E get(int index)|返回指定索引处的元素|

---

### ⚔️ 4. List 的两个主要实现类 (ArrayList vs LinkedList)

这是面试必考的对比题，主要考底层数据结构。

#### A. ArrayList (动态数组) 🔥 *最常用*

- ​**底层**​：​**数组**。
- ​**特点**：

  - ​**查询快**：有索引，直接定位。
  - ​**增删慢**：如果在中间插入或删除，后面的元素都需要整体挪动位置。
- ​**场景**：读多写少（绝大多数业务场景）。

#### B. LinkedList (双向链表)

- ​**底层**​：​**双向链表**。
- ​**特点**：

  - ​**查询慢**：每次都要从头或尾一个一个找。
  - ​**增删快**：只需要断开和连接指针，不需要挪动其他元素（尤其是首尾操作极快）。
- ​**场景**：需要频繁在首尾增删元素（如实现栈或队列）。

---

## 	**ArrayList**和**LinkedList**的底层原理（结合源码分析）

- ---

  ### 1. ArrayList 源码深度剖析

  ​**核心本质**​：ArrayList 的外壳是一个 `List`​，但剥开外壳，它的内核就是一个**对象数组** `Object[]`。

  #### A. 核心成员变量 (成员)

  Java

  ```
  public class ArrayList<E> extends AbstractList<E> ... {
      // 1. 底层真正存数据的数组
      // transient 表示该字段不参与默认序列化
      transient Object[] elementData; 

      // 2. 集合的大小（实际装了多少个元素）
      private int size;

      // 3. 默认初始容量常量 = 10
      private static final int DEFAULT_CAPACITY = 10;

      // 4. 空数组常量（用于懒加载）
      private static final Object[] DEFAULTCAPACITY_EMPTY_ELEMENTDATA = {};
  }
  ```

  #### B. 构造器 (懒加载机制)

  面试高频点：**new ArrayList() 的时候，数组长度是多少？**

  - ​**JDK 1.7**：直接创建一个长度为 10 的数组。
  - ​**JDK 1.8**​：创建一个​**空数组**​。只有当第一次 `add` 数据时，才变成 10。

  Java

  ```
  // JDK 1.8 源码
  public ArrayList() {
      // 刚创建时，只是把空数组赋值给 elementData，此时长度为 0
      this.elementData = DEFAULTCAPACITY_EMPTY_ELEMENTDATA;
  }
  ```

  #### C. add 方法与扩容 (最核心)

  当你调用 `list.add("A")` 时，内部发生了什么？

  Java

  ```
  public boolean add(E e) {
      // 1. 确认容量够不够，不够就扩容,此时size为0
      ensureCapacityInternal(size + 1); 
      // 2. 填入数据
      elementData[size++] = e;
      return true;
  }

  // --- 扩容核心逻辑 grow() ---
  private void grow(int minCapacity) {
      // oldCapacity: 旧容量
      int oldCapacity = elementData.length;
      
      // newCapacity: 新容量
      // 核心算法：oldCapacity + (oldCapacity >> 1)
      // >> 1 表示右移一位，等同于除以 2
      // 所以：新容量 = 旧容量 + 0.5倍旧容量 = 1.5倍旧容量
      int newCapacity = oldCapacity + (oldCapacity >> 1);

      // ... 省略部分边界检查代码 ...

      // 3. 真正干活的地方：数据迁移
      // Arrays.copyOf 底层调用 System.arraycopy，在堆内存中创建新数组并复制数据
      elementData = Arrays.copyOf(elementData, newCapacity);
  }
  ```

  ​**源码结论**：

  1. ​**扩容公式**​：`old + old >> 1` (即 1.5 倍)。
  2. ​**性能损耗点**​：`Arrays.copyOf`​。每次扩容都要创建新数组、搬运旧数据，所以​**如果在循环中频繁 add，且不指定初始容量，性能会很差**。

  ---

  ### 2. LinkedList 源码深度剖析

  ​**核心本质**​：LinkedList 是由一个个**节点 (Node)**  对象串联起来的。它没有“数组”这个概念。

  #### A. 核心内部类 (Node)

  LinkedList 的心脏是这个静态内部类：

  Java

  ```
  private static class Node<E> {
      E item;       // 真正存的数据
      Node<E> next; // 指向下一个节点的“指针” (引用)
      Node<E> prev; // 指向前一个节点的“指针”

      Node(Node<E> prev, E element, Node<E> next) {
          this.item = element;
          this.next = next;
          this.prev = prev;
      }
  }
  ```

  #### B. 核心成员变量

  LinkedList 只需要拿捏住“头”和“尾”。

  Java

  ```
  public class LinkedList<E> ... {
      transient int size = 0;

      // 指向第一个节点的指针
      transient Node<E> first;

      // 指向最后一个节点的指针 (关键！为了让 add 速度变快)
      transient Node<E> last;
  }
  ```

  #### C. add 方法 (链接的艺术)

  当你调用 `list.add("B")`​ 时，其实是调用了 `linkLast`，把新节点挂在链表末尾。

  Java

  ```
  void linkLast(E e) {
      // 1. 先记下当前的尾节点
      final Node<E> l = last;
      
      // 2. 创建一个新节点
      // 构造器参数：(前驱节点是 l, 数据是 e, 后继节点是 null)
      final Node<E> newNode = new Node<>(l, e, null);
      
      // 3. 更新尾指针，现在 newNode 也就是最新的尾巴了
      last = newNode;
      
      if (l == null)
          // 如果之前链表是空的，那新节点既是尾也是头
          first = newNode;
      else
          // 如果之前有数据，把旧尾巴的 next 指向新节点 (连起来了！)
          l.next = newNode;
          
      size++;
  }
  ```

  ​**源码结论**：

  1. ​**没有扩容**：LinkedList 根本不存在“扩容”的代码，存一个创建一个 Node，内存是不连续的。
  2. ​**指针操作**​：`add`​ 操作纯粹是引用的赋值（`next`​, `prev`​, `first`​, `last`），速度非常快，不涉及数据搬运。

  ---

  ### 💡 源码层面的终极对比

  |**对比项**|**ArrayList 源码特征**|**LinkedList 源码特征**||||
  | --| --------------------------------------------| --------------------------------------| --| --| --|
  |**内存结构**|​`Object[] elementData`(连续内存)|​`Node<E>`对象链 (离散内存)||||
  |**扩容方式**|​`old + (old >> 1)`​(1.5倍) +`System.arraycopy`|无需扩容，`new Node(...)`||||
  |**添加元素**|检查容量 -\> 扩容(可能) -\> 数组赋值|创建 Node -\> 修改 prev/next 指针||||
  |**获取元素**|​`return elementData[index]`(直接访问)|​`node(index)`(for 循环从头或尾遍历)||||

  ​ **👨‍💻 开发实战建议**：

  - ​**ArrayList**​：当你明确知道大概要存多少数据时，请使用带参构造器 `new ArrayList<>(100)`​，这样可以避免中间多次扩容带来的 `System.arraycopy` 性能损耗。
  - **LinkedList**：面试时可以说得头头是道，但实际开发中（特别是结合 Spring 开发 Web 应用时），99% 的情况请无脑用 `ArrayList`。因为现代 CPU 对连续内存（数组）有缓存优化，而链表的离散内存对 CPU 缓存不友好。
- LinkededList通常用于实现栈和队列，栈是先进后出的，队列是先进先出的。java中编写了pop和push接口用于实现入栈和出栈的操作
- ```java
  package com.itheima.demo7list;

  import java.util.LinkedList;

  public class ListDemo2 {
      public static void main(String[] args) {
          // 目标：用LinkedList做一个队列对象。
          LinkedList<String> queue = new LinkedList<>();
          // 入队，最右边，尾节点
          queue.addLast("赵敏");
          queue.addLast("西门吹雪");
          queue.addLast("陆小凤");
          queue.addLast("石观音");
          System.out.println(queue); // [赵敏, 西门吹雪, 陆小凤, 石观音]

          // 出队
          System.out.println(queue.removeFirst());
          System.out.println(queue.removeFirst());
          System.out.println(queue);

          System.out.println("-------------------------------------------------");

          // 做一个栈
          LinkedList<String> stack = new LinkedList<>();
          // 压栈
          stack.push("第1颗子弹");
          stack.push("第2颗子弹");
          stack.push("第3颗子弹");
          stack.push("第4颗子弹");
          System.out.println(stack);  // [第4颗子弹, 第3颗子弹, 第2颗子弹, 第1颗子弹]

          // 出栈
          System.out.println(stack.pop());
          System.out.println(stack.pop());
          System.out.println(stack);
      }
  }
  /* 源码：public void push(E e) {
          addFirst(e);
  	在最左边，头结点。
  		public E pop() {
          return removeFirst();
      		}
      }*/
  ```

---

5. 集合的遍历方式

对于 List 集合，我们有三种遍历方式：

1. **普通 for 循环** (List 独有，因为有索引)：
2. **增强 for 循环** (最常用，语法糖)：
3. **迭代器 Iterator** (它是 Java 集合遍历的底层逻辑)：
4. **Lambda表达式**

 **⚠️ 迭代器的一个大坑：ConcurrentModificationException**

在使用迭代器遍历时（包括增强 for 循环），**千万不要**直接用集合对象 `list.remove()` 删除元素，否则会报错。

- **解决**：必须用迭代器自己的 `it.remove()` 方法。

- 这是一个非常经典且高频的面试题，也是开发中最容易踩的坑之一。

  为什么 Java 要这么设计？明明我只是删了个元素，它为什么要报异常？

  为了让你彻底理解，我们还是**从源码层面**来破案。核心机制叫做 ​**Fail-Fast (快速失败机制)** 。

  ---

  ### 💥 1. 案发现场 (复现异常)

  我们先看一段一定会报错的代码：

  Java

  ```
  List<String> list = new ArrayList<>();
  list.add("Java");
  list.add("Python");
  list.add("C++");

  // ❌ 错误示范：增强 for 循环中直接用 list 删除
  for (String s : list) {
      if ("Python".equals(s)) {
          list.remove(s); // <--- 这里的 list.remove 是罪魁祸首
      }
  }
  // 运行结果：Exception in thread "main" java.util.ConcurrentModificationException
  ```

  ​**原因解析**：

  增强 `for`​ 循环（for-each）本质上是 **Iterator（迭代器）**  的语法糖。编译器把上面代码变成了这样：

  Java

  ```
  Iterator<String> it = list.iterator();
  while (it.hasNext()) {
      String s = it.next(); // <--- 异常其实是在这一步抛出的！
      if ("Python".equals(s)) {
          list.remove(s); 
      }
  }
  ```

  ---

  ### 🕵️‍♂️ 2. 源码破案 (modCount 机制)

  要理解为什么报错，必须看 `ArrayList`​ 及其内部类 `Itr` (迭代器实现) 的源码。

  这里有两个关键变量：

  1. ​**​`modCount`​**​  **(实际修改次数)** ​：定义在 `AbstractList`​ 中。List 每 `add`​ 或 `remove`​ 一次，这个值就 `+1`。
  2. ​**​`expectedModCount`​**​  **(预期修改次数)** ​：定义在 `Itr`​ (迭代器) 中。当迭代器​**创建的那一瞬间**​，它会把当时的 `modCount` 抄写一份给自己保存。

  #### 场景还原：

  1. ​**初始化**​：List 存了 3 个元素，假设经过 3 次 add，`modCount = 3`。
  2. ​**创建迭代器**​：`Iterator it = list.iterator();`

     - 迭代器内部记录：`expectedModCount = 3` (刚创建时两者相等)。
  3. ​**开始遍历**：

     - 第一次 `next()`​：`3 == 3`，通过。
  4. ​**触发删除**​：调用 ​**​`list.remove("Python")`​** 。

     - ​**重点**​：`list.remove`​ 会导致 List 的 `modCount`​ 变成 ​**4**。
     - ​**但是**​：迭代器里的 `expectedModCount`​ 还是 ​**3**。
  5. ​**继续遍历**​：下一次循环调用 ​**​`it.next()`​** 。

     - 我们来看 `next()` 的源码：

  Java

  ```
  // ArrayList 的内部类 Itr 中的 next() 方法
  public E next() {
      // 1. 进来第一件事：检查版本号！
      checkForComodification(); 
      // ... 省略取数据代码 ...
  }

  final void checkForComodification() {
      // 核心判断：List 的实际修改次数 vs 迭代器预期的次数
      if (modCount != expectedModCount)
          // 如果不相等，说明在我迭代期间，有人动了 List（哪怕是你自己动的）
          throw new ConcurrentModificationException(); // 抛出异常
  }
  ```

  ​**结论**​：因为 `list.remove()`​ 修改了 `modCount`​，导致和迭代器手中的 `expectedModCount`​ **对不上号了**，迭代器认为集合也是“不安全”的，于是立即抛出异常终止程序。

  ---

  ### ✅ 3. 解决方案 (it.remove)

  为什么改成 `it.remove()` 就没事了呢？看看源码就知道了。

  Java

  ```
  // 迭代器自己的 remove 方法
  public void remove() {
      // ... 检查 ...
      
      // 1. 调用 List 的 remove 删除元素 (List 的 modCount 会 +1)
      ArrayList.this.remove(lastRet); 
      
      // 2. 【关键一步】：同步版本号！！！
      // 把 List 变动后的 modCount 重新赋值给迭代器的 expectedModCount
      expectedModCount = modCount; 
      
      // ...
  }
  ```

  ​**原理**​：迭代器自己的 `remove`​ 方法在删完元素后，做了一步  **“自我修正”**  的操作，手动把自己的 `expectedModCount`​ 更新成了最新的 `modCount`​。这样下一次调用 `next()`​ 检查时，`4 == 4`，就能通过了。

  ​**正确代码**：

  Java

  ```
  Iterator<String> it = list.iterator();
  while (it.hasNext()) {
      String s = it.next();
      if ("Python".equals(s)) {
          it.remove(); // ✅ 使用迭代器的删除，包含“同步版本号”的逻辑
      }
  }
  ```

  ---

  ### 🚀 4. 现代写法 (Java 8+)

  虽然 `it.remove()`​ 是经典考点，但在实际开发中（JDK 1.8 之后），我们通常使用更优雅的 ​**​`removeIf`​**：

  Java

  ```
  // 一行代码搞定，底层原理其实就是迭代器遍历删除
  list.removeIf(s -> "Python".equals(s));
  ```

  ### 总结

  1. ​**Exception 来源**​：`next()`​ 方法中的 `checkForComodification()` 检查。
  2. ​**核心原因**​：`modCount`​ (List的) 和 `expectedModCount`​ (迭代器的) ​**数值不一致**。
  3. ​**解决**​：使用 `Iterator`​ 自己的 `remove()`​ 方法，因为它会在删除后**同步**这两个值。

# 常用遍历：

---

### 1. 两种“foreach”的本质区别

|**特性**|**增强 for 循环 (Enhanced For-Loop)**|**forEach 方法 (Java 8 API)**||||
| --| ----------------------------| --------------------------------------| --| --| --|
|**语法**|​`for (T v : list) { ... }`|​`list.forEach(v -> ...)`||||
|**出现版本**|JDK 5|JDK 8||||
|**本质**|**语法糖**(底层是 Iterator 迭代器)|**方法调用**(内部迭代)||||
|**控制流**|可以`break`​(中断),`continue`​(跳过),`return`|**不能** `break/continue`​(只能`return`跳过当前这一个)||||
|**适用范围**|任何数组、实现`Iterable`接口的集合|Collection 集合、Map 集合、Stream 流||||

---

### 2. 实战代码演示

#### ✅ 场景一：遍历 List / Set (单列集合)

​**推荐程度**​：两者皆可，逻辑简单用 `forEach`​，复杂逻辑用 `增强for`。

Java

```
List<String> list = Arrays.asList("Java", "Vue", "Spring");

// 方式 A：增强 for 循环 (传统，通用)
for (String s : list) {
    if (s.equals("Vue")) continue; // 可以跳过
    System.out.println(s);
}

// 方式 B：forEach 方法 + Lambda (简洁)
list.forEach(s -> System.out.println(s));

// 方式 C：forEach 方法 + 方法引用 (极简)
list.forEach(System.out::println);
```

#### ✅ 场景二：遍历 Map (双列集合) 🔥 *重点*

​**推荐程度**​：强烈推荐使用 ​**方式 B (**​**​`forEach`​**​ **方法)** ，因为方式 A 太繁琐了！

Java

```
Map<String, Integer> map = new HashMap<>();
map.put("张三", 23);
map.put("李四", 24);

// 方式 A：增强 for 循环 (必须通过 entrySet 或 keySet 间接遍历)
for (Map.Entry<String, Integer> entry : map.entrySet()) {
    String key = entry.getKey();
    Integer value = entry.getValue();
    System.out.println(key + " = " + value);
}

// 方式 B：forEach 方法 (JDK 8+ 最优雅)
// Map 的 forEach 接收一个 BiConsumer (两个参数)
map.forEach((k, v) -> {
    System.out.println(k + " = " + v);
});
```

#### ✅ 场景三：遍历 数组 (Array)

​**推荐程度**​：推荐使用 ​**增强 for 循环**。

Java

```
String[] arr = {"A", "B", "C"};

// 方式 A：增强 for 循环 (最快，最直观)
for (String s : arr) {
    System.out.println(s);
}

// 方式 B：必须先转成流 (稍微麻烦一点点)
Arrays.stream(arr).forEach(System.out::println);
```

---

### 💡 核心避坑指南

1. **想在遍历中删除元素？**

   - ❌ ​**增强 for 循环**​：直接 `list.remove()`​ 会报 `ConcurrentModificationException`。
   - ❌ ​**forEach 方法**：同上，也会报错。
   - ✅ ​**正确做法**​：必须使用 **​`Iterator`​**​ **的** **​`remove()`​** ​ 方法，或者使用 **​`list.removeIf()`​**  (Java 8)。
2. **想中途停止 (break)？**

   - ✅ ​**增强 for 循环**​：支持 `break`。
   - ❌ ​**forEach 方法**：不支持！它一旦开始，除非抛异常，否则会把所有元素跑完。

### 📝 总结

- 如果你只是简单的​**打印、处理数据**​，用 `forEach()` + Lambda，代码最漂亮。
- 如果你需要​**中途停止、复杂逻辑控制**​，乖乖用 `for ( : )` 增强循环。
- 如果你是 ​**Map**​，无脑选 `map.forEach((k,v) -> ...)`。
